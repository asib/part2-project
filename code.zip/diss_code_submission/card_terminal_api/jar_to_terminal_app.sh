ant compile && ant jar && cp ./build/jar/card_terminal_api.jar ../card_terminal/lib/card_terminal_api.jar && cp ./build/jar/card_terminal_api.jar ../door_opacity_fs_impl/lib/card_terminal_api.jar
