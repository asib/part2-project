./cmp.sh && ./run.sh $@
