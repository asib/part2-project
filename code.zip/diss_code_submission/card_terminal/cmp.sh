ant clean && ant compile && ant jar
