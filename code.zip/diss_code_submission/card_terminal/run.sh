java -jar ./build/jar/card_terminal.jar $@
