ant jc && gpshell gpinstall.txt
