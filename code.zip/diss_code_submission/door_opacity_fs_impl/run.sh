java -jar ./build/jar/door_opacity_fs_impl.jar $@
